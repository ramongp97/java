package ejercicio2;

public class Principal {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		Funcionario f = new Funcionario("12345678A", "Garcia Ramon", "calle falsa 1", "23/09/2021", 8888.88);

		f.getAtributos();

	}

}
