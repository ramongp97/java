package ejercicio2;

public class Funcionario {

	private String rut;
	private String nombreApellidos;
	private String domicilio;
	private String fechaNacimiento;
	private double sueldoBruto;
	
	public Funcionario() {
		
	}
	
	public Funcionario(String rUT, String nombreApellidos, String domicilio, String fechaNacimiento,
			double sueldoBruto) {
		this.rut = rUT;
		this.nombreApellidos = nombreApellidos;
		this.domicilio = domicilio;
		this.fechaNacimiento = fechaNacimiento;
		this.sueldoBruto = sueldoBruto;
	}

	public String getRut() {
		return this.rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getNombreApellidos() {
		return this.nombreApellidos;
	}

	public void setNombreApellidos(String nombreApellidos) {
		this.nombreApellidos = nombreApellidos;
	}

	public String getDomicilio() {
		return this.domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getFechaNacimiento() {
		return this.fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public double getSueldoBruto() {
		return this.sueldoBruto;
	}

	public void setSueldoBruto(double sueldoBruto) {
		this.sueldoBruto = sueldoBruto;
	}
	
	public void getAtributos() {
		System.out.println(""+this.rut+","+this.nombreApellidos+","+this.fechaNacimiento+","+this.sueldoBruto);
	}
	
	
	
	
}
