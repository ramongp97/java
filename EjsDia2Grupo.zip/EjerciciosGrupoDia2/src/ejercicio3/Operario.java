package ejercicio3;

public class Operario extends Empleado{

	protected String grado;

	public Operario() {
		super();
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public Operario(String nombre, String apellido1, String apellido2, String direccion, String fono, String email,
			String departamento, double sueldo, String grado) {
		super(nombre, apellido1, apellido2, direccion, fono, email, departamento, sueldo);
		this.grado=grado;
	}

	public String getGrado() {
		return this.grado;
	}

	public void setGrado(String grado) {
		this.grado = grado;
	}

	@Override
	public String toString() {
		return "Operario [grado=" + grado + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2="
				+ apellido2 + ", direccion=" + direccion + ", fono=" + fono + ", email=" + email + ", departamento="
				+ departamento + ", sueldo=" + sueldo + "]";
	}

	public double sueldoMensual() {
		return this.sueldo/12;
	}

	
	
	
	
	
	
	
	
}
