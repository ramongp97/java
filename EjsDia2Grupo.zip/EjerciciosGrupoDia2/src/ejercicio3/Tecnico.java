package ejercicio3;

public class Tecnico extends Operario{

	private String especialidad;

	public Tecnico() {
		super();
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public Tecnico(String nombre, String apellido1, String apellido2, String direccion, String fono, String email,
			String departamento, double sueldo, String grado, String especialidad) {
		super(nombre, apellido1, apellido2, direccion, fono, email, departamento, sueldo, grado);
		// TODO Esbozo de constructor generado autom�ticamente
		this.especialidad=especialidad;
	}

	public String getEspecialidad() {
		return this.especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	@Override
	public String toString() {
		return "Tecnico [especialidad=" + especialidad + ", grado=" + grado + ", nombre=" + nombre + ", apellido1="
				+ apellido1 + ", apellido2=" + apellido2 + ", direccion=" + direccion + ", fono=" + fono + ", email="
				+ email + ", departamento=" + departamento + ", sueldo=" + sueldo + "]";
	}
	
	
	
	
	
}
