package ejercicio3;

public class Empleado {
	
	protected String nombre;
	protected String apellido1;
	protected String apellido2;
	protected String direccion;
	protected String fono;
	protected String email;
	protected String departamento;
	protected double sueldo;

	
	
	public Empleado(String nombre, String apellido1, String apellido2, String direccion, String fono, String email,
			String departamento, double sueldo) {
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.direccion = direccion;
		this.fono = fono;
		this.email = email;
		this.departamento = departamento;
		this.sueldo = sueldo;
	}

	public Empleado() {
		
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", direccion="
				+ direccion + ", fono=" + fono + ", email=" + email + ", departamento=" + departamento + ", sueldo="
				+ sueldo + "]";
	}
	
	

}
