package ejercicio3;

public class Directivo extends Empleado{
	
	protected String socio;

	public Directivo() {
		super();
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public Directivo(String nombre, String apellido1, String apellido2, String direccion, String fono, String email,
			String departamento, double sueldo, String socio) {
		super(nombre, apellido1, apellido2, direccion, fono, email, departamento, sueldo);
		// TODO Esbozo de constructor generado autom�ticamente
		this.socio=socio;
	}
	
	

	public String getSocio() {
		return this.socio;
	}

	public void setSocio(String socio) {
		this.socio = socio;
	}
	
	

	@Override
	public String toString() {
		return "Directivo [socio=" + socio + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2="
				+ apellido2 + ", direccion=" + direccion + ", fono=" + fono + ", email=" + email + ", departamento="
				+ departamento + ", sueldo=" + sueldo + "]";
	}

	public double sueldoMensual() {
		return this.sueldo/12;
	}
	
	

}
