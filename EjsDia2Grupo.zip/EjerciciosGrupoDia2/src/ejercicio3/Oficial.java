package ejercicio3;

public class Oficial extends Operario{

	protected String nivel;

	public Oficial() {
		super();
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public Oficial(String nombre, String apellido1, String apellido2, String direccion, String fono, String email,
			String departamento, double sueldo, String grado, String nivel) {
		super(nombre, apellido1, apellido2, direccion, fono, email, departamento, sueldo, grado);
		this.nivel=nivel;
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public String getNivel() {
		return this.nivel;
	}

	public void setNivel(String nivel) {
		this.nivel = nivel;
	}

	@Override
	public String toString() {
		return "Oficial [nivel=" + nivel + ", grado=" + grado + ", nombre=" + nombre + ", apellido1=" + apellido1
				+ ", apellido2=" + apellido2 + ", direccion=" + direccion + ", fono=" + fono + ", email=" + email
				+ ", departamento=" + departamento + ", sueldo=" + sueldo + "]";
	}
	
	
	
	
}
