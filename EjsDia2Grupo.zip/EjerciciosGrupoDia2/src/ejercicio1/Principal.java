package ejercicio1;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		Scanner teclado = new Scanner(System.in);

		System.out.println("Introduce usuario:");
		String user=teclado.nextLine();
		
		System.out.println("Introduce contrase�a:");
		String pass=teclado.nextLine();
		
		Login log= new Login();
		log.registro(user, pass);
		
	}

}
