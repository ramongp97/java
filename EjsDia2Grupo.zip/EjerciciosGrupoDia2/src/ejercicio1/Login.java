package ejercicio1;

import java.util.Scanner;

public class Login {
	
	private String user1= "admin";
	private String pass1= "1234";
	
	private String numCuenta= "495868493";
	private String titularCuenta= "Ramon";
	private int inter=5;
	private double eurosADolares = 1.17;
	
	private String user2= "user";
	private String pass2= "1234";
	private double saldo= 0.0;
	
	
	public Login() {
		
	}
	
	public void registro(String user, String pass) {
		if(user.equals("user") && pass.equals(pass2)) {
			this.menuUser();
		}
		else if(user.equals("admin") && pass.equals(pass1)) {
			this.menuAdmin();
		}
		else {
			System.out.println("Usuario o contrase�a no valido");
		}
	}
	
	public void menuUser() {
		System.out.println("Usuario");
		String s="";
		Scanner teclado = new Scanner(System.in);
		
		while(!s.equals("0")) {
		System.out.println("introduce 1 para modificar contrase�a:");
		System.out.println("introduce 2 para depositar dinero:");
		System.out.println("introduce 3 para retirar dinero:");
		System.out.println("introduce 4 para consultar saldo:");
		System.out.println("introduce 5 para pasar euros a dolares:");
		System.out.println("introduce 0 para salir");
		
		s=teclado.nextLine();
		
		if(s.equals("1")) {
			System.out.println("introduce la nueva contrase�a");
			s=teclado.nextLine();
			pass2=s;
			System.out.println("Se ha cambiado la contrase�a. La nueva contrase�a es "+pass2);
		}
		else if(s.equals("2")) {
			System.out.println("introduce el dinero a depositar:");
			int cantidad=teclado.nextInt();
			this.saldo=this.saldo+cantidad;
		}
		else if(s.equals("3")) {
			System.out.println("introduce el dinero a retirar:");
			int cantidad=teclado.nextInt();
			if(cantidad>this.saldo) {
				this.saldo=this.saldo-cantidad;
				System.out.println("Has retirado "+cantidad+" y te quedan "+this.saldo+" euros");
				
			}
			else {
				System.out.println("Has retirado "+this.saldo+" y te quedan 0 euros");
				this.saldo=0;
			}
			
		}
		else if(s.equals("4")) {
			System.out.println("tu saldo es de: "+this.saldo);
		}
		else if(s.equals("5")) {
			System.out.println("tu saldo en dolares es de: "+(this.saldo*this.eurosADolares));
		}
		}
		
		teclado.close();
	}
	
	public void menuAdmin() {
		System.out.println("Admin");
		String s="";
		Scanner teclado = new Scanner(System.in);
		
		while(!s.equals("0")) {
		System.out.println("introduce 1 para modificar contrase�a:");
		System.out.println("introduce 2 para ver el numero de cuenta:");
		System.out.println("introduce 3 para ver el titular de la cuenta:");
		System.out.println("introduce 4 para consultar saldo:");
		System.out.println("introduce 5 para ver el interes anual:");
		System.out.println("introduce 0 para salir");
		
		s=teclado.nextLine();
		
		if(s.equals("1")) {
			System.out.println("introduce la nueva contrase�a");
			s=teclado.nextLine();
			pass1=s;
			System.out.println("Se ha cambiado la contrase�a. La nueva contrase�a es "+pass1);
		}
		else if(s.equals("2")) {
			System.out.println("tu numero de cuenta es: "+this.numCuenta);
		}
		else if(s.equals("3")) {
			System.out.println("el titular de la cuenta es: "+this.titularCuenta);
		}
		else if(s.equals("4")) {
			System.out.println("tu saldo es de: "+this.saldo);
		}
		else if(s.equals("5")) {
			System.out.println("el interes anual es de: "+this.inter);
		}
		}
		teclado.close();
	}
	
}
