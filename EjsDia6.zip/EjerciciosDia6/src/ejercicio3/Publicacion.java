package ejercicio3;

public class Publicacion {
	
	private String tipo;
	private String titulo;
	private String codigo;
	private int a�oPub;
	private boolean prestable, prestado;
	
	
	

	public Publicacion(String tipo, String titulo, String codigo, int a�oPub, boolean prestable) {
		super();
		this.tipo = tipo;
		this.titulo = titulo;
		this.codigo = codigo;
		this.a�oPub = a�oPub;
		this.prestable = prestable;
		this.prestado = false;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public int getA�oPub() {
		return this.a�oPub;
	}

	public void setA�oPub(int a�oPub) {
		this.a�oPub = a�oPub;
	}

	public boolean isPrestable() {
		return this.prestable;
	}

	public void setPrestable(boolean prestable) {
		this.prestable = prestable;
	}

	public boolean isPrestado() {
		return this.prestado;
	}

	public void setPrestado(boolean prestado) {
		this.prestado = prestado;
	}

	@Override
	public String toString() {
		return "Publicacion [tipo=" + tipo + ", titulo=" + titulo + ", codigo=" + codigo + ", a�oPub=" + a�oPub
				+ ", prestable=" + prestable + ", prestado=" + prestado + "]";
	}
	
	
	
	

}
