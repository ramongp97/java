package ejercicio3;

import java.util.ArrayList;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente

		//crear arraylist y a�adir los 6 elementos
		ArrayList<Publicacion> objetos = new ArrayList<Publicacion>();
		objetos.add(new Publicacion("libro", "la Biblia", "fjebvjej", 1972, true));
		objetos.add(new Publicacion("libro", "codigo da vinci", "aoejfcn", 2016, true));
		objetos.add(new Publicacion("libro", "Mi Lucha", "faeuvbsd", 1999, true));
		objetos.add(new Publicacion("revista", "HOLA", "niesvnvs", 2021, false));
		objetos.add(new Publicacion("revista", "REVISTAXD", "cascbdn", 2015, false));
		objetos.add(new Publicacion("revista", "ADIOS", "napknfc", 2009, false));
		
		//prestar un libro
		objetos.get(1).setPrestado(true);
		//mostrar informacion de los objetos
		for(Publicacion p:objetos) {
			System.out.println(p.toString());
		}
		
		//llamar a las otras 2 funciones
		cantPublicaciones(objetos);
		saldoPrestados(objetos);
		
	}
	
	public static void cantPublicaciones(ArrayList<Publicacion> ap) {
		//mostrar anteriores a 2002
		int contador=0;
				for(Publicacion p:ap) {
					if(p.getA�oPub()<2002) {
						contador++;
					}
				}
		System.out.println("La cantidad de publicaciones anteriores a 2002 es: "+contador);
	}
	
	public static void saldoPrestados(ArrayList<Publicacion> ap) {
		//mostrar cuantos hay prestados
		int contador=0;
		for(Publicacion p:ap) {
			if(p.isPrestado()==true) {
				contador++;
			}
		}
System.out.println("La cantidad de publicaciones prestadas es: "+contador);
	}

}
