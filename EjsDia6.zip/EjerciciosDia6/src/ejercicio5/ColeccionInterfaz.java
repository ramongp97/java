package ejercicio5;

public interface ColeccionInterfaz {

	public void a�adir(Publicacion3 p);
	
	public boolean estaVacia();
	
	public Publicacion3 extraer();
	
	public Publicacion3 primero();
	
}
