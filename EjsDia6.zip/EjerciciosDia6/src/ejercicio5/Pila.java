package ejercicio5;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class Pila implements ColeccionInterfaz{
	private int tama�o;//tama�o maximo
	private int contador=0;//tama�o actual
	private ArrayList<Publicacion3> objetos= new ArrayList<Publicacion3>();
	
	
	public Pila(int tama�o) {
		this.tama�o=tama�o;
	}
	
	
	
	public int getContador() {
		return this.contador;
	}





	@Override
	public void a�adir(Publicacion3 p) {
		// si cabe se a�ade
		if(this.contador<this.tama�o) {
			this.objetos.add(p);
			contador++;
		}
		else {
			//si ya esta llena primero eliminar el objeto mas antiguo
			this.objetos.remove(0);
			this.objetos.add(p);
		}
		
	}

	@Override
	public boolean estaVacia() {
		// comprueba si el arraylist esta vacio
		return this.getContador()==0;
	}

	@Override
	public Publicacion3 extraer() {
		// si esta vacia tira excepcion, si no quita el ultimo elemento y lo devuelve
		if(this.contador==0) {
			throw new NoSuchElementException("La lista esta vacia");
		}
		else {
			contador--;
			Publicacion3 p=this.objetos.get(contador);
			this.objetos.remove(contador);
			return p;
		}
	}

	@Override
	public Publicacion3 primero() {
		// si esta vacia tira excepcion, si no devuelve el ultimo elemento
		if(this.contador==0) {
			throw new NoSuchElementException("La lista esta vacia");
		}
		else {
			Publicacion3 p=this.objetos.get(contador-1);
			return p;
		}
	}
	
	
	
}
