package ejercicios1y2;

import java.util.Arrays;
import java.util.Scanner;

//leer frase y darle la vuelta
public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		
		Scanner teclado = new Scanner(System.in);
		
		String s="";
		
		//Obtener frase y pasarsela a funcion
		System.out.println("Introduce una frase: ");
		s=teclado.nextLine();
		s=modificarFrase(s);
		
		
		System.out.println(s);

	}
	
	public static String modificarFrase(String s) {
		String ultimaPalabra,primeraPalabra="";
		String ss=s;
		String [] palabras;
		
		//separar frase en palabras
		palabras=s.split(" ");
		
		//intercambiar primera y ultima palabra
		primeraPalabra=palabras[0];
		ultimaPalabra=palabras[palabras.length-1];
		palabras[0]=ultimaPalabra;
		palabras[palabras.length-1]=primeraPalabra;
		ss="";
		
		//volver a formar String
		for(int i=0;i<palabras.length;i++) {
			ss=ss+palabras[i]+" ";
		}
		
		return ss;
	}

}
