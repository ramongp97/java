package ejercicios1y2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente

		Scanner teclado = new Scanner(System.in);
		int num=0;
		
		System.out.println("Introduce un numero de DNI: ");
		//intenta leer el numero
		try {
		num= teclado.nextInt();
		}
		catch(InputMismatchException e) {
			System.out.println("No has introducido un numero");
		}
		
		//llamar a funcion de verificacion de DNI
		verificarDNI(num);
		
	}
	
	public static void verificarDNI(int i) {
		int num=i;
		int modulo=0;
		String codigo="TRWAGMYFPDXBNJZSQVHLCKE";
		char c;
		
		//comprobar que numero esta en rango adecuado
		if(num>=0 && num<=9999999) {
			//calcular modulo y obtener letra correspondiente
			modulo=num%23;
			System.out.println("Al numero "+num+" le corresponde la letra "+ codigo.charAt(modulo));
		}
		else {
			System.out.println("El numero introducido no es v�lido");
		}
	}

}
