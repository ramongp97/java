package ejercicio4;

public class Publicacion2 {
	
	protected String titulo;
	protected String codigo;
	protected int a�oPub;
	
	
	

	public Publicacion2(String titulo, String codigo, int a�oPub) {
		this.titulo = titulo;
		this.codigo = codigo;
		this.a�oPub = a�oPub;
	}

	
	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public int getA�oPub() {
		return this.a�oPub;
	}

	public void setA�oPub(int a�oPub) {
		this.a�oPub = a�oPub;
	}

	
	
	
	

}
