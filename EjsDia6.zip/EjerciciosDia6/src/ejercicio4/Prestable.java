package ejercicio4;

public interface Prestable {

	public boolean prestado();
	public void devolver();
	public void prestar();
	
}
