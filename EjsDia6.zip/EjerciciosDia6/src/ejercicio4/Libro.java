package ejercicio4;

public class Libro extends Publicacion2 implements Prestable{

	private boolean prestado;

	public Libro(String titulo, String codigo, int a�oPub) {
		super(titulo, codigo, a�oPub);
		this.prestado=false;
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public boolean isPrestado() {
		return this.prestado;
	}

	public void setPrestado(boolean prestado) {
		this.prestado = prestado;
	}

	@Override
	public String toString() {
		return "Libro [prestado=" + prestado + ", titulo=" + titulo + ", codigo=" + codigo + ", a�oPub=" + a�oPub + "]";
	}

	@Override
	public boolean prestado() {
		// TODO Esbozo de m�todo generado autom�ticamente
		return this.prestado;
	}

	@Override
	public void devolver() {
		// TODO Esbozo de m�todo generado autom�ticamente
		this.setPrestado(false);
	}

	@Override
	public void prestar() {
		// TODO Esbozo de m�todo generado autom�ticamente
		this.setPrestado(true);
	}
	
	
	
	
	
}
