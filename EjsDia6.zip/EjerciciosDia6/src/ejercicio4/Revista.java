package ejercicio4;

public class Revista extends Publicacion2{
	
	private int numero;

	

	public Revista(String titulo, String codigo, int a�oPub) {
		super(titulo, codigo, a�oPub);
		this.numero=numero;
		// TODO Esbozo de constructor generado autom�ticamente
	}

	public int getNumero() {
		return this.numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "Revista [numero=" + numero + ", titulo=" + titulo + ", codigo=" + codigo + ", a�oPub=" + a�oPub + "]";
	}
	
	

}
