package ejercicio;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		Scanner teclado = new Scanner(System.in);
		
		double num1, num2, resultado;
		String s="a";
		Operaciones op= new Operaciones();
		
		//preguntar primer numero
		System.out.println("Introduce el primer numero: ");
		resultado= teclado.nextDouble();
		
		while(!s.equals("XD")) {
			
			//opciones del cliente
		System.out.println("introduce + para sumar:");
		System.out.println("introduce - para restar:");
		System.out.println("introduce * para multiplicar:");
		System.out.println("introduce / para dividir:");
		System.out.println("introduce XD para salir:");
		
		s=teclado.next();
		
		switch (s) {
		case "+":
			num1=resultado;
			num2= siguienteNumero(teclado);
			resultado=op.sumar(resultado, num2);
			System.out.println("El resultado de "+num1+"+"+num2+" = "+resultado);
			break;
			
		case "-":
			num1=resultado;
			num2= siguienteNumero(teclado);
			resultado=op.restar(resultado, num2);
			System.out.println("El resultado de "+num1+"-"+num2+" = "+resultado);
			break;
			
		case "*":
			num1=resultado;
			num2= siguienteNumero(teclado);
			resultado=op.multiplicar(resultado, num2);
			System.out.println("El resultado de "+num1+"*"+num2+" = "+resultado);
			break;
			
		case "/":
			num1=resultado;
			num2= siguienteNumero(teclado);
			resultado=op.dividir(resultado, num2);
			System.out.println("El resultado de "+num1+"/"+num2+" = "+resultado);
			break;
			
		case "XD":
			System.out.println("Saliendo del programa");
			break;
			
		default:
			System.out.println("Entrada no valida. Vuelve a elegir operacion.");
		}
		}

	}
	
	//funcion para introducir un nuevo numero
	public static double siguienteNumero(Scanner s) {
		System.out.println("Introduce el siguiente numero:");
		double numNuevo=0.0;
		try {
			numNuevo=s.nextDouble();
		}
		catch(Exception e) {
			System.out.println("No has introducido un numero.");
			siguienteNumero(s);
		}
		finally {
			return numNuevo;
		}
	}

}
