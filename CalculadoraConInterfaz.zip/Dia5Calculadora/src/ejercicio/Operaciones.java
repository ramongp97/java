package ejercicio;

public class Operaciones implements InterfazOperaciones{

	
	
	//constructor sin parametros
	public Operaciones() {
		
	}
	
	//metodos para las 4 operaciones usando lambda
	public double sumar(double a, double b) {
		InterfazOperaciones suma= (n,m) -> n+m;
		
		return suma.operar(a, b);
	}
	
	public double restar(double a, double b) {
		InterfazOperaciones resta= (n,m) -> n-m;
		
		return resta.operar(a, b);
	}
	
	public double multiplicar(double a, double b) {
		InterfazOperaciones multi= (n,m) -> n*m;
		
		return multi.operar(a, b);
	}
	
	public double dividir(double a, double b) {
		InterfazOperaciones divi= (n,m) -> n/m;
		
		double divResultado=0.0;
		
		try {
			divResultado=divi.operar(a, b);
		}
		catch(Exception e) {
			System.out.println("Has dividido por 0");
		}
		
		return divResultado;
	}
	

	@Override
	public double operar(double a, double b) {
		// TODO Esbozo de m�todo generado autom�ticamente
		return 0;
	}
	
	
	
	
	
}
