package ejercicio;

public interface InterfazOperaciones {
	
	double operar(double a, double b);


}
