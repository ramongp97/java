package ejercicios;

import java.util.Scanner;

public class Ej4Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		
		float nota=0.0f;
		
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("Introduce Nota");
		
		nota= teclado.nextFloat();
		
		System.out.println(""+nota);
		
		if(nota < 3.9f) {
			System.out.println("Insuficiente");
		}
		else if(nota <5.9f) {
			System.out.println("Suficiente");
		}
		else {
			System.out.println("Bien");
		}

	}

}
