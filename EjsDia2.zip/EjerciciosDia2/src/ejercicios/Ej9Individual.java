package ejercicios;

public class Ej9Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		
		for(int i=1; i<5; i++) {
			for(int j=3; j>0; j-- ) {
				int suma= i*10+j;
				System.out.println(suma);
			}
		}

	}

}
