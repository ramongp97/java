package ejercicios;

import java.util.Scanner;

public class Ej1Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el primer numero");
		
		int num1= teclado.nextInt();
		
		System.out.println("Introduce el segundo numero");
		
		int num2= teclado.nextInt();
		
		if(num1==num2) {
			System.out.println("los numeros son iguales");
		}
		else {
			System.out.println("los numeros no son iguales");
		}

	}

}
