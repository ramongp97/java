package ejercicios;

import java.util.Scanner;

public class Ej2Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el primer numero");
		
		int num1= teclado.nextInt();
		
		System.out.println("Introduce el segundo numero");
		
		int num2= teclado.nextInt();
		
		if(num1==num2) {
			System.out.println("los numeros son iguales");
		}
		else if(num1>num2){
			System.out.println("el primer numero es mas grande");
		}
		else {
			System.out.println("el segundo numero es mas grande");
		}

	}

}
