package ejercicios;

import java.util.Scanner;

public class Ej10Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
		Scanner teclado = new Scanner(System.in);
		
		String user1= "admin";
		String pass1= "1234";
		
		String user2= "user";
		String pass2= "1234";
		
		System.out.println("Introduce usuario:");
		String user=teclado.nextLine();
		
		System.out.println("Introduce contrase�a:");
		String pass=teclado.nextLine();
		
		if(user.equals("user") && pass.equals(pass2)) {
			System.out.println("Usuario");
			String s="";
			
			while(!s.equals("0")) {
			System.out.println("introduce 1 para modificar contrase�a:");
			System.out.println("introduce 0 para salir");
			
			s=teclado.nextLine();
			
			if(s.equals("1")) {
				System.out.println("introduce la nueva contrase�a");
				s=teclado.nextLine();
				pass2=s;
				System.out.println("Se ha cambiado la contrase�a. La nueva contrase�a es "+pass2);
			}
			}
			
		}
		else if(user.equals("admin") && pass.equals(pass1)) {
			System.out.println("Admin");
			String s="";
			
			while(!s.equals("0")) {
			System.out.println("introduce 1 para modificar contrase�a:");
			System.out.println("introduce 0 para salir");
			
			s=teclado.nextLine();
			
			if(s.equals("1")) {
				System.out.println("introduce la nueva contrase�a");
				s=teclado.nextLine();
				pass1=s;
				System.out.println("Se ha cambiado la contrase�a. La nueva contrase�a es "+pass1);
			}
			}
		}
		else {
			System.out.println("Usuario o contrase�a no valido");
		}
		
		

	}
	
	/*public static void menuUser(Scanner tec) {
		String s="";
		
		while(!s.equals("0")) {
		System.out.println("introduce 1 para modificar contrase�a:");
		System.out.println("introduce 0 para salir");
		
		s=tec.nextLine();
		
		if(s.equals("1")) {
			System.out.println("introduce la nueva contrase�a");
			s=tec.nextLine();
			pass1=s;
		}
		}*/
	

}
