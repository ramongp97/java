package ejercicios;

import java.util.Scanner;

public class Ej3Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el primer numero");
		
		int num1= teclado.nextInt();
		
		System.out.println("Introduce el segundo numero");
		
		int num2= teclado.nextInt();
		
		System.out.println("Introduce el tercer numero");
		
		int num3= teclado.nextInt();
		
		if(num1<=num2 && num1<=num3 && num2<=num3) {
			System.out.println(num1+", "+num2+", "+num3);
		}
		else if(num1<=num2 && num1<=num3 && num2>=num3){
			System.out.println(num1+", "+num3+", "+num2);
		}
		else if(num1<=num2 && num1>=num3 && num2>=num3){
			System.out.println(num2+", "+num1+", "+num3);
		}
		else if(num1<=num2 && num1<=num3 && num2>=num3){
			System.out.println(num2+", "+num3+", "+num1);
		}
		else if(num1>=num2 && num1<=num3 && num2<=num3){
			System.out.println(num3+", "+num1+", "+num2);
		}
		else if(num1<=num2 && num1<=num3 && num2<=num3){
			System.out.println(num3+", "+num2+", "+num1);
		}

	}

}
