package ejercicios;

import java.util.Scanner;

public class Ej5Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el dia de la primera fecha:");
		
		int dia1= teclado.nextInt();
		
		System.out.println("Introduce el mes de la primera fecha");
		
		int mes1= teclado.nextInt();
		
System.out.println("Introduce el dia de la segunda fecha:");
		
		int dia2= teclado.nextInt();
		
		System.out.println("Introduce el mes de la segunda fecha");
		
		int mes2= teclado.nextInt();
		
		int difDias=Math.abs(dia2-dia1);
		int difMeses=Math.abs(mes2-mes1);
		int difTotal=difMeses*30+difDias;
		
		System.out.println("La diferencia en dias es de "+ difTotal);

	}

}
