package ejercicios;

import java.util.Scanner;

public class Ej6Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		int num=0;
		while(num>=0) {
			System.out.println("Introduce un numero positivo para ver su cuadrado o negativo para salir:");
			
			num= teclado.nextInt();
			
			if(num>=0) {
				int cuadrado=num*num;
				System.out.println("El cuadrado de "+num+" es "+cuadrado);
			}
			else {
				System.out.println("Saliendo del prgrama");
			}
		}

	}

}
