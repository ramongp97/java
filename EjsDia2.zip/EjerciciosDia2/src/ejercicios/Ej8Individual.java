package ejercicios;

import java.util.Scanner;

public class Ej8Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		int numero=-1;
		
		while(numero<0 || numero>10) {
			System.out.println("Introduce un numero del 0 al 10");
			numero=teclado.nextInt();
		}
		
		for(int i=1; i<11 ; i++) {
			System.out.println(""+numero+"*"+i+"="+(numero*i));
		}

	}

}
