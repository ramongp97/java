package ejercicios;

import java.util.Scanner;

public class Ej7Individual {

	public static void main(String[] args) {
		// TODO Esbozo de m�todo generado autom�ticamente
Scanner teclado = new Scanner(System.in);
		
		int sueldo=0;
		int suma=0;
		int mayores=0;
		
		for(int i=0; i<5 ; i++) {
			System.out.println("Introduce el sueldo numero "+(i+1));
			
			sueldo=teclado.nextInt();
			suma=suma+sueldo;
			
			if(sueldo>2000) {
				mayores++;
			}
		}
		
		System.out.println("La suma de los sueldos es "+suma+" y superan los 2000 euros "+mayores);

	}

}
